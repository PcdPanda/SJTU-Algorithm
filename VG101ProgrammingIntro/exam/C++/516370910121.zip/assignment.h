#ifndef CTEMPLATE_ASSIGNMENT_H
#define CTEMPLATE_ASSIGNMENT_H
int getExerciseNumber(int argc, char* argv[]);
extern int ex1(int argc, char* argv[]);
extern void ex2();
#endif //CTEMPLATE_ASSIGNMENT_H
