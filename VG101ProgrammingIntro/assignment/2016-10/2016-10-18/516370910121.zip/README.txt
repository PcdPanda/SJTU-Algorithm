Assigment 3:
Ex.1��Accurate calculations
Input:None
Output:The grains of wheat
The script uses loop algorithm to calculate the how many grains of wheat.

Ex.2��Structure
Input:None
Output:The largest quantity item and how old the items are in average
The script uses structure to show the largest quantity item and how old the items are in average.

Ex.3��Input and output
Input:A integer n
Output:A txt file
You need to input a integer n and the function can output a txt file as the assignment requires.

Ex.4��Ploting
Input:None
Output:A figure
The script will plot a aimple house and a car.

Author:
Pan Chongdan
Student ID:516370910121