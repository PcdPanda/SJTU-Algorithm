clear all,clc;
n=0;
for i=1:64
    n=n+2^(i-1);
end
disp([char(vpa(n)),' grains of wheat had to be given to the creator']);