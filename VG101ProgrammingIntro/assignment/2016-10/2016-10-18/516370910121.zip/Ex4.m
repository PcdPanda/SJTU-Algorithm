clear all,clc;
hold off;
a=0:pi/100:2*pi
x1=[0 20 20 0 0];
y1=[0 0 16 16 0];
x2=[0 20 10 0];
y2=[16 16 24 16];
x3=[25 35 35 33 32 28 27 25 25];
y3=[2 2 5 5 8 8 5 5 2];
x4=26.5+cos(a);
x5=33.5+cos(a);
y4=1+sin(a);
plot(x1,y1,x2,y2,x3,y3);
hold;
fill(x1,y1,'y',x2,y2,'r',x3,y3,'m',x4,y4,'b',x5,y4,'b');


