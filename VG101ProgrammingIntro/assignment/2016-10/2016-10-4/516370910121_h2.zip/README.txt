Assigment 2:
Ex.1��Algorithms and basic loops 
Since the script uses loop algorithm,you need to keep prompting until the input is a year number which is an integer which may be negative.
Then it will use the formula to judge whether the year number is a leap year

Ex.2��Algorithms and loops
You need to prompt a number and the script will display the next Pythagorean prime and two corresponding numbers by useing loop algorithm.
First,it will find the next Pythagorean prime by the form.Then,it will start a loop to find the two corresponding numbers

Ex.3��Recursion
The function uses resursion algorithm to read the input number smaller than 999999999 in English words.
First it will cut the number into 3 numbers per part.Then a subfunction will be used to intpret every part of 0-3 numbers.
Finally,another subfunction will combine them together. 

ex.4��Mathematical functions, loops, and recursion
You need to input the function expression whose independent value is x with quotation marks,the low bound,the up bound and the precision orderly.
You can use either the iterative function or the recursion function.It will use the corresponding algorithm to calculate the root.

ex.5��Control statements
You need to prompt a positive and it will return the least Armstrong number bigger than it 
Author:
Pan Chongdan
Student ID:516370910121