//
// Created by Pan Chongdan on 2016/11/7.
#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H
int getExerciseNumber(int argc, char* argv[]);
extern void ex1();
extern void ex2();
extern void ex3();
extern void ex4();
extern void ex6(); 
#endif 
