clc;
clear all;
disp(numel(primes(100000)));% The number of primes between 1 and 100000
disp(randi([1,10],1,5))%The product of 5 random numbers in the range 1 to 10
