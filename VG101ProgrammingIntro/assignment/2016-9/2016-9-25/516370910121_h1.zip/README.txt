Assigment 1:
ex.1��Writing proper documentation 

ex.2��Basic scripting

ex.3��Algorithms
Eratosthenes' method:
Eratosthenes calculated the circumference of the Earth at local noon on the summer when the shadow 
of someone looking down a deep well blocked the reflection of the Sun on the water.He measured the 
Sun's angle of elevation which is 1/50th of a circle.Then he concluded the Earth's circumference 
was fifty times that distance because Earth is sphere.Finally,he got the distance between Syene and 
Alexandria is 5,000 stadia and he calculated the circumference of the Earth.
 
Inputs:the distance between Syene and Alexandria,the Sun's angle of elevation
Outputs:the circumference of the Earth
Algorithm:The circumference =The distance/the angle

ex.4��Vectors

ex.5��Compact coding

Author:
Pan Chongdan
Student ID:516370910121