clc;
clear all;
a=input('enter your number: ');%input how much weight in oroginal weight
u=input('enter your original unit: ','s');
%if unit is stones then u=1,unit is pounds then u=2,unit is kg then u=3 
switch u
    case 'stones'
    a=14*a;
    disp([num2str(a),' pounds'])
    case 'pounds'
    a=a*6.35/14;
    disp([num2str(a),' kg'])
    case 'kg'
    a=a/6.35;
    disp([num2str(a),' stones'])
end  
