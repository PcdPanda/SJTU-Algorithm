clear all;
clc;
prompt=input('please enter the distance:');%input the total distance
laps=fix(prompt/400);%divide the distance into laps and get the integer
rem=(prompt-laps*400);%calculate the remaining distance which is smaller than 400
clc;%clean the screen and display the laps and the remaining distance
disp([num2str(laps),' laps and ',num2str(rem),' m']);